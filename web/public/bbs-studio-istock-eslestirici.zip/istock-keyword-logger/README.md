# iStock Kırmızı Kelime Eşleştirici (Chrome Eklentisi)

## Ne yapar?
Tek işi var: `esp.gettyimages.com` yükleme panelinde iStock'un **kırmızı**
gösterdiği (tanımadığı/onaylamadığı) bir anahtar kelimeyi silip yerine ne
yazdığınızı **"eski → yeni"** çifti olarak toplar. Dosya adıyla, tam
kelime listesiyle ilgilenmez — amaç sadece bu çiftleri biriktirip, siz
kendi elinizle uygulamanızdaki **"iStock Kütüphanesi"** eşleştirme
özelliğine ekleyebilesiniz.

## Nasıl tespit ediyor?
Panelde gerçek bir kırmızı kelimeyi inceleyerek doğrulandı: iStock'un
tanımadığı kelimeler `rgb(211, 47, 47)` kenarlık rengiyle (kırmızı)
gösteriliyor. Siz o kelimeyi silince, eklenti onu **bekleme kuyruğuna**
alır; siz yeni kelimeyi yazıp ekleyene kadar (birkaç saniye de sürse,
birkaç dakika de) orada bekler ve ilk yeni kelime eklendiğinde eşleştirilip
kaydedilir. Bekleyen bir kırmızı kelime 5 dakika içinde eşleşmezse ya da
başka bir dosyaya geçerseniz iptal edilir.

*(v2.0'da "aynı 0.5 sn'lik pencerede" olması şartı vardı — bu, silme ile
yazma arasında normalde geçen birkaç saniyeyi kaçırıp hiçbir şey
yakalamamasına sebep oluyordu. v2.1'de bu düzeltildi ve canlı sayfada
~22 saniyelik gerçekçi bir gecikmeyle test edilip doğrulandı.)*

**Not:** Aynı anda (çok hızlı art arda) birden fazla kırmızı kelimeyi
değiştirirseniz, eklenti hangi eskinin hangi yeniyle eşleştiğini bilemez;
her yeni eklenen kelimeyi kuyruktaki EN ESKİ bekleyen kırmızıyla eşleştirir
(sırayla). En güvenlisi: kelimeleri teker teker değiştirmek.

## Kurulum
1. `chrome://extensions` → sağ üstten **Geliştirici modu**'nu açın.
2. **Paketlenmemiş öğe yükle** → bu klasörü (`istock-keyword-logger`) seçin.
3. Daha önce eski sürümü yüklediyseniz: eklentinin kartındaki **yenile (↻)**
   ikonuna basın, sonra `esp.gettyimages.com` sekmesini **F5** ile yenileyin.

## Kullanım
1. Panelde bir dosya seçip anahtar kelimeleri düzenlemeye başlayın.
2. Kırmızı bir kelime gördüğünüzde, silin ve yerine doğrusunu yazın.
3. Eklenti simgesine tıklayıp popup'ı açın — "Eski (kırmızı) → Yeni"
   tablosunda az önceki değişikliği görürsünüz. (Otomatik yakalama
   çalışmazsa **Şimdi Tara** ile elle tetikleyebilirsiniz.)
4. Listeyi beğendiğinizde **📋 Panoya Kopyala**'ya basın — bu, metni
   uygulamanızdaki **iStock Kütüphanesi** modalının **"Toplu içe aktar"**
   kutusuna doğrudan yapıştırabileceğiniz formatta kopyalar:
   ```
   outdoor → Outdoors
   fresh → Freshness
   ```
5. Uygulamanızı açın → iStock Kütüphanesi ikonuna tıklayın → "Toplu içe
   aktar"ı genişletin → yapıştırın → **İçe Aktar**. Bu kadar.
6. Yanlış/istemediğiniz bir eşleştirme varsa popup'taki satırın sonundaki
   **✕** ile tek tek silebilir, ya da **Temizle** ile tümünü sıfırlayabilirsiniz.

CSV olarak da indirmek isterseniz **CSV İndir** butonu iki kolonlu
(`KirmiziKelime,YeniKelime`) bir dosya verir — ama günlük kullanım için
"Panoya Kopyala" daha hızlıdır.

## Sorun giderme
- **En hızlı tanı yolu — Konsol logları:** Panel sayfasında F12 → Console
  sekmesini açın. Sayfa yüklendiğinde `[iStock Eşleştirici] content script
  yüklendi...` satırını görmelisiniz — görmüyorsanız content script hiç
  çalışmıyor demektir (aşağıdaki "bağlantı kurulamadı" maddesine bakın).
  Bir kelime silip eklediğinizde `[iStock Eşleştirici] tarama: {...}` ve
  eşleşme olduğunda `✅ EŞLEŞTİ: eski → yeni` satırlarını görürsünüz. Bu
  loglar neyin neden çalışmadığını (yanlış dosya, chip bulunamadı, kırmızı
  tespit edilmedi vb.) doğrudan gösterir.
- **"Bu sekme esp.gettyimages.com üzerinde değil"**: yanlış sekmedesiniz.
- **"Sayfayla bağlantı kurulamadı"**: content script bu sekmeye enjekte
  edilmemiş; sayfayı F5 ile yenileyin (özellikle eklentiyi yeni
  kurduysanız/güncellediyseniz).
- **Kırmızı renk tespiti tutmuyor**: Getty arayüzü güncellenmiş olabilir.
  F12 → bir kırmızı kelimeye tıklayıp Elements'te seçin →
  `getComputedStyle(el).borderColor` konsola yazıp gerçek rengi görün,
  `content.js` başındaki `RED_BORDER` değerini buna göre güncelleyin.
