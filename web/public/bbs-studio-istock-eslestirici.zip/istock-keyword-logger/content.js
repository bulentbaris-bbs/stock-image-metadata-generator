// content.js (v3.2 - Kesin Çözüm)
const FILE_NAME_SELECTOR = '[data-cy="metadata-filename"]';
const CHIP_SELECTOR = '[data-cy="metadata-keyword-chip"]';
const REPLACEMENTS_KEY = 'istockReplacements';
const RED_BORDER = 'rgb(211, 47, 47)';

let activeRedChipText = null;

function getCurrentFileName() {
  const el = document.querySelector(FILE_NAME_SELECTOR);
  return el ? el.textContent.trim() : '';
}

function isRedChip(chip) {
  return getComputedStyle(chip).borderColor === RED_BORDER;
}

async function addReplacement(from, to) {
  if (!from || !to || from === to) return;
  
  try {
    const data = await chrome.storage.local.get(REPLACEMENTS_KEY);
    const existing = data[REPLACEMENTS_KEY] || {};
    existing[from] = to;
    
    await chrome.storage.local.set({ [REPLACEMENTS_KEY]: existing });
    console.log('[BBS Studio] 🎯 ÖNERİDEN SEÇİLDİ VE KAYDEDİLDİ:', from, '→', to);
  } catch (err) {
    console.error('[BBS Studio] Kaydetme hatası:', err);
  }
}

// 1. Kullanıcı kırmızı bir kelimeye tıkladığında onu hedef olarak belleğe al
document.addEventListener('mousedown', function(e) {
  const chip = e.target.closest(CHIP_SELECTOR);
  if (chip && isRedChip(chip)) {
    activeRedChipText = chip.textContent.trim();
    console.log('[BBS Studio] Hedef kırmızı kelime seçildi:', activeRedChipText);
  }
}, true);

// 2. iStock'un öneri listesinden bir kelimeye tıklandığında tetiklenir
document.addEventListener('click', function(e) {
  const suggestionItem = e.target.closest('[role="option"], .suggestion-item, .dropdown-item, li[id*="react-autowhatever"]');
  
  if (suggestionItem && activeRedChipText) {
    const selectedSuggestion = suggestionItem.textContent.trim();
    if (selectedSuggestion) {
      addReplacement(activeRedChipText, selectedSuggestion);
      activeRedChipText = null;
    }
  }
}, true);

// Dosya değiştiğinde hedefi temizle
let prevFileName = getCurrentFileName();
const observer = new MutationObserver(function() {
  const currentFileName = getCurrentFileName();
  if (currentFileName !== prevFileName) {
    prevFileName = currentFileName;
    activeRedChipText = null;
  }
});
observer.observe(document.body, { childList: true, subtree: true });

console.log('[BBS Studio Eşleştiricisi v3.2] Aktif ve hazır.');