// popup.js
const REPLACEMENTS_KEY = 'istockReplacements';

document.addEventListener('DOMContentLoaded', function() {
  var statusEl = document.getElementById('status');
  var tbody = document.getElementById('tbody');
  var scanMsgEl = document.getElementById('scanMsg');

  function showScanMsg(text, kind) {
    if (scanMsgEl) {
      scanMsgEl.textContent = text;
      scanMsgEl.className = kind || '';
    }
  }

  function loadReplacements(callback) {
    chrome.storage.local.get(REPLACEMENTS_KEY, function(data) {
      callback(data[REPLACEMENTS_KEY] || {});
    });
  }

  function saveReplacements(map, callback) {
    var obj = {};
    obj[REPLACEMENTS_KEY] = map;
    chrome.storage.local.set(obj, function() {
      if (callback) callback();
    });
  }

  function render(map) {
    var entries = Object.entries(map);
    if (statusEl) statusEl.textContent = entries.length + ' eşleştirme';
    if (!tbody) return;
    
    tbody.innerHTML = '';

    if (entries.length === 0) {
      var trEmpty = document.createElement('tr');
      var tdEmpty = document.createElement('td');
      tdEmpty.colSpan = 4;
      tdEmpty.className = 'empty';
      tdEmpty.textContent = 'Henüz eşleştirme yok. iStock panelinde kırmızı kelimeye tıklayıp önerilen doğru kelimeyi seçin.';
      trEmpty.appendChild(tdEmpty);
      tbody.appendChild(trEmpty);
      return;
    }

    entries.forEach(function(entry) {
      var from = entry[0];
      var to = entry[1];

      var tr = document.createElement('tr');

      var tdFrom = document.createElement('td');
      tdFrom.className = 'from';
      tdFrom.textContent = from;

      var tdArrow = document.createElement('td');
      tdArrow.className = 'arrow';
      tdArrow.textContent = '→';

      var tdTo = document.createElement('td');
      tdTo.className = 'to';
      tdTo.textContent = to;

      var tdDel = document.createElement('td');
      var delBtn = document.createElement('button');
      delBtn.className = 'delBtn';
      delBtn.textContent = '✕';
      delBtn.title = 'Bu eşleştirmeyi sil';
      
      delBtn.addEventListener('click', function() {
        loadReplacements(function(current) {
          delete current[from];
          saveReplacements(current, function() {
            render(current);
          });
        });
      });
      
      tdDel.appendChild(delBtn);

      tr.appendChild(tdFrom);
      tr.appendChild(tdArrow);
      tr.appendChild(tdTo);
      tr.appendChild(tdDel);
      tbody.appendChild(tr);
    });
  }

  function refresh() {
    loadReplacements(function(map) {
      render(map);
    });
  }

  function escapeCsvField(field) {
    var str = (field !== undefined && field !== null) ? String(field) : '';
    if (str.indexOf('"') !== -1 || str.indexOf(',') !== -1 || str.indexOf('\n') !== -1) {
      return '"' + str.replace(/"/g, '""') + '"';
    }
    return str;
  }

  var copyBtn = document.getElementById('copyBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', function() {
      loadReplacements(function(map) {
        var entries = Object.entries(map);
        if (entries.length === 0) {
          showScanMsg('Kopyalanacak eşleştirme yok.', 'err');
          return;
        }
        var text = entries.map(function(e) { return e[0] + ' → ' + e[1]; }).join('\n');
        
        navigator.clipboard.writeText(text).then(function() {
          showScanMsg(entries.length + ' eşleştirme panoya kopyalandı!', 'ok');
        }).catch(function(err) {
          showScanMsg('Kopyalanamadı: ' + err.message, 'err');
        });
      });
    });
  }

  var exportBtn = document.getElementById('exportBtn');
  if (exportBtn) {
    exportBtn.addEventListener('click', function() {
      loadReplacements(function(map) {
        var lines = [];
        // Başlık satırı kaldırıldı, doğrudan kelime çiftleri ekleniyor
        Object.entries(map).forEach(function(entry) {
          lines.push(escapeCsvField(entry[0]) + ',' + escapeCsvField(entry[1]));
        });
        
        var csv = '\uFEFF' + lines.join('\r\n');
        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        var stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        a.href = url;
        a.download = 'bbs-studio-istock-esleme-' + stamp + '.csv';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      });
    });
  }

  var clearBtn = document.getElementById('clearBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', function() {
      chrome.storage.local.remove(REPLACEMENTS_KEY, function() {
        refresh();
      });
    });
  }

  refresh();
});